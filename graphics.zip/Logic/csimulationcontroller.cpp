#include "csimulationcontroller.h"
#include "MapViews/csimulationview.h"
#include <QMouseEvent>
#include <QMessageBox>

CSimulationController::CSimulationController(CApplicationController *application_controller, CEditableMap *map_model, SSimulationConfiguration simulation_configuration) :
    CBaseController(application_controller),
    m_simulation_configuration(simulation_configuration)
{
    m_map_model = map_model;
    m_map_view = new CSimulationView(m_map_model, this);

    auto traffic_lights = m_map_model->get_traffic_lights();

    for(auto traffic_light : *traffic_lights){
        traffic_light->set_ligths_durations(simulation_configuration.m_traffic_lights_duration);
    }

    srand(time(NULL));
    std::random_device rd;
    m_generator = new std::mt19937(rd());

    prepare_pedestrians_attributes_distributions();
    prepare_cars_attributes_distributions();

    m_simulation_timer.setInterval(m_simulation_step_interval);
    connect(&m_simulation_timer, &QTimer::timeout, this, &CSimulationController::slot_process_simulation_step);
}

CSimulationController::~CSimulationController()
{
    if(m_map_model != nullptr){
        delete m_map_model;
    }

    if(m_map_view != nullptr){
        delete m_map_view;
    }

    delete m_generator;
    m_pedestrian_attributes_distributions.clear();
    m_cars_attributes_distributions.clear();
}

void CSimulationController::set_user_to_place_creation_func(CRoadUser *(*creation_func)())
{
    if(m_road_user_is_being_placed){
        m_map_model->erase_road_user(m_road_user_being_placed);
    }

    m_current_creation_func = creation_func;
    m_road_user_being_placed = creation_func();
    m_map_model->add_road_user(m_road_user_being_placed, QPointF(0, 0));
    prepare_validation_rect();
    m_road_user_is_being_placed = true;
}

bool CSimulationController::process_wheel_event(QWheelEvent *event)
{
    if(m_road_user_is_being_placed){
        if(m_road_user_being_placed->is_rotable()){
            rotate_road_user_being_placed(event);
            return true;
        }
    }
    return false;
}

void CSimulationController::process_mouse_move_event(QMouseEvent *event)
{
    if(!m_road_user_is_being_placed)
        return;

    QPointF mouse_event_mapped_to_scene = this->m_map_view->mapToScene(event->pos());
    QRectF element_bounding_rect = m_road_user_being_placed->boundingRect();
    if(m_road_user_is_being_placed)
    {
        m_road_user_being_placed -> setPos(mouse_event_mapped_to_scene.x() - element_bounding_rect.width()/2,
                                       mouse_event_mapped_to_scene.y() - element_bounding_rect.height()/2);
        m_validation_rect -> setPos(mouse_event_mapped_to_scene.x() - element_bounding_rect.width()/2 - m_val_rect_size_offset/2,
                                  mouse_event_mapped_to_scene.y() - element_bounding_rect.height()/2 - m_val_rect_size_offset/2);
        update_validation_rect(event);
    }
}

void CSimulationController::process_mouse_press_event(QMouseEvent *event)
{
    if(event->button() == Qt::LeftButton){
        if(m_road_user_is_being_placed){
            place_user_and_prepare_next(event);
        }
        else{
            auto *item_at_mouse_pos = m_map_model->itemAt(this->m_map_view->mapToScene(event->pos()), this->m_map_view->transform());
            auto *road_user = dynamic_cast<CRoadUser*>(item_at_mouse_pos);

            if(road_user){
                m_road_user_being_placed = road_user;
                m_road_user_is_being_placed = true;
                m_road_user_is_being_edited = true;
                prepare_validation_rect();
                update_validation_rect(event);

                m_validation_rect->setTransformOriginPoint(m_validation_rect->boundingRect().center());
                m_validation_rect->setRotation(m_road_user_being_placed->rotation());
                return;
            }

            auto traffic_light = dynamic_cast<CTrafficLight*>(item_at_mouse_pos);

            if(traffic_light){
                m_traffic_light_being_configured = traffic_light;
                STrafficLightsDuration tld = traffic_light->get_traffic_lights_durations();
                if(tld.full_lights_cycle_time() > 1000){
                    tld.m_green_ligth_duration = tld.m_green_ligth_duration/1000;
                    tld.m_red_ligth_duration = tld.m_red_ligth_duration/1000;
                    tld.m_yellow_ligth_duration = tld.m_yellow_ligth_duration/1000;
                    tld.m_red_and_yellow_ligths_duration = tld.m_red_and_yellow_ligths_duration/1000;
                }
                emit signal_traffic_light_configuration_requested(tld);
            }
            else{
                auto road_user = dynamic_cast<CRoadUser*>(item_at_mouse_pos);
                if(road_user){
                    m_road_user_being_configured = road_user;
                    SRoadUsersBasicParameters parameters = road_user->get_basic_parameters();

                    emit signal_road_user_configuration_requested(parameters);
                }
            }
        }
    }
    else if(event->button() == Qt::RightButton){
        erase_selected_user(event);
    }
}

void CSimulationController::start_simulation()
{
    auto traffic_lights = m_map_model->get_traffic_lights();
    for(auto traffic_light : *traffic_lights){
        traffic_light->start_simulation();
    }

    m_simulation_timer.start();
}

void CSimulationController::pause_simulation()
{
    auto traffic_lights = m_map_model->get_traffic_lights();
    for(auto traffic_light : *traffic_lights){
        traffic_light->pause_simulation();
    }
    m_simulation_timer.stop();
}

void CSimulationController::resume_simulation()
{
    auto traffic_lights = m_map_model->get_traffic_lights();
    for(auto traffic_light : *traffic_lights){
        traffic_light->resume_simulation();
    }
    m_simulation_timer.start();
}

void CSimulationController::restart_simulation()
{

}

void CSimulationController::set_simulation_configuration(SSimulationConfiguration simulation_configuration)
{
    m_simulation_configuration = simulation_configuration;
    m_pedestrian_attributes_distributions.clear();
    m_cars_attributes_distributions.clear();

    prepare_pedestrians_attributes_distributions();
    prepare_cars_attributes_distributions();

    auto road_users = m_map_model->get_road_users();
    for(auto road_user : *road_users){
        if(road_user->get_road_user_type() == ERoadUsers::pedestrian){
            road_user->set_basic_parameters(prepare_road_users_parameters(m_pedestrian_attributes_distributions));
        }
        else{
            road_user->set_basic_parameters(prepare_road_users_parameters(m_cars_attributes_distributions));
        }
    }
}

void CSimulationController::set_simulation_speed(uint simulation_speed)
{
    m_simulation_speed = simulation_speed;
    auto traffic_lights = m_map_model->get_traffic_lights();
    for(auto traffic_light : *traffic_lights){
        traffic_light->set_simulation_speed(simulation_speed);
    }

    m_simulation_timer.start(m_simulation_step_interval/simulation_speed);
}

void CSimulationController::configure_traffic_light(STrafficLightsDuration traffic_lights_duration)
{
    if(m_traffic_light_being_configured == nullptr){
        return;
    }

    m_traffic_light_being_configured->set_ligths_durations(traffic_lights_duration, true);
}

void CSimulationController::place_user_and_prepare_next(QMouseEvent *event)
{
    QPoint placement_position = get_current_user_legal_position(event);

    if(get_current_user_position_validity(event) == EMapElementPositionValidity::invalid){
        QMessageBox msg_box;
        msg_box.setText("Selected road user position is not valid.");
        msg_box.setStandardButtons(QMessageBox::Ok);
        msg_box.setDefaultButton(QMessageBox::Ok);
        msg_box.exec();
        return;
    }
    m_road_user_being_placed->setPos(placement_position);

    if(m_road_user_is_being_edited){
        m_road_user_is_being_edited = false;
        m_road_user_is_being_placed = false;
        m_map_model->erase_item(m_validation_rect);
        event->accept();
        return;
    }
    else{
        if(m_road_user_being_placed->get_road_user_type() == ERoadUsers::pedestrian){
            m_road_user_being_placed->set_basic_parameters(prepare_road_users_parameters(m_pedestrian_attributes_distributions));
        }
        else{
            m_road_user_being_placed->set_basic_parameters(prepare_road_users_parameters(m_cars_attributes_distributions));
        }
    }

    qreal previous_element_rotation = (int)m_road_user_being_placed->rotation();
    auto new_road_user_to_place = m_current_creation_func();

    new_road_user_to_place->set_current_movement_plane(m_road_user_being_placed->get_current_movement_plane());
    new_road_user_to_place->set_horizontal_move_direction(m_road_user_being_placed->get_horizontal_move_direction());
    new_road_user_to_place->set_vertical_move_direction(m_road_user_being_placed->get_vertical_move_direction());

    m_road_user_being_placed = new_road_user_to_place;
    QPointF mouse_event_mapped_to_scene = this->m_map_view->mapToScene(event->pos());
    QPointF new_element_pos = QPointF(mouse_event_mapped_to_scene.x() - m_road_user_being_placed->boundingRect().toRect().width()/2,
                                      mouse_event_mapped_to_scene.y() - m_road_user_being_placed->boundingRect().toRect().height()/2);
    m_map_model->add_road_user(m_road_user_being_placed, new_element_pos);
    QPointF center = m_road_user_being_placed->boundingRect().center();
    m_road_user_being_placed->setTransformOriginPoint(center);
    m_road_user_being_placed->setRotation(previous_element_rotation);
    update_validation_rect(event);
    m_simulation_is_ready = true;
}

QPoint CSimulationController::get_current_user_legal_position(QMouseEvent *event)
{
    QPointF mouse_event_mapped_to_scene = this->m_map_view->mapToScene(event->pos());
    if(m_road_user_being_placed->get_road_user_type() == ERoadUsers::pedestrian){
        return QPoint(mouse_event_mapped_to_scene.x(), mouse_event_mapped_to_scene.y());
    }
    else{
        auto colliding_items = m_map_model->collidingItems(m_road_user_being_placed);
        CRoadway *roadway = nullptr;
        for(auto colliding_item : colliding_items){
            auto maybe_roadway = dynamic_cast<CRoadway*>(colliding_item);
            if(maybe_roadway){
                roadway = maybe_roadway;
                break;
            }
        }

        if(roadway == nullptr){
            return QPoint(-1, -1);
        }

        auto rodaway_test = roadway->boundingRect();
        auto roadway_rect = rodaway_test.toRect();
        auto roadway_width = roadway_rect.width();
        auto roadway_height = roadway_rect.height();

        int x_roadway_offset = 0;
        int y_roadway_offset = 0;

        if(abs((int)roadway->rotation()) % 180 == 90 && roadway_height != roadway_width){
            x_roadway_offset = abs(roadway_width - roadway_height)/2;
            y_roadway_offset = abs(roadway_width - roadway_height)/2;
            roadway_width = roadway_height;
            roadway_height = roadway_rect.width();
        }

        QPoint real_roadway_pos = QPoint(roadway->pos().x() + x_roadway_offset, roadway->pos().y() - y_roadway_offset);

        auto car_bounding_rect = m_road_user_being_placed->boundingRect();
        auto car_rect = car_bounding_rect.toRect();
        auto car_width = car_rect.width();
        auto car_height = car_rect.height();

        int x_car_offset = 0;
        int y_car_offset = 0;

        if(abs((int)m_road_user_being_placed->rotation()) % 180 == 90 && car_width != car_height){
            x_car_offset = abs(car_width - car_height)/2;
            y_car_offset = abs(car_width - car_height)/2;
        }

        if((int)(m_road_user_being_placed->rotation()) % 180 != 0){
            car_width = m_road_user_being_placed->boundingRect().height();
            car_height = m_road_user_being_placed->boundingRect().width();
        }

        //Place car on the proper lane
        if(m_road_user_being_placed->get_current_movement_plane() == EMovementPlane::vertical){
            int y_car_pos = mouse_event_mapped_to_scene.y();
            if(m_road_user_being_placed->get_vertical_move_direction() == EVerticalMoveDirection::up){
                int x_car_pos = real_roadway_pos.x() - x_car_offset + roadway_width - car_width - cars_roadside_offset;
                return QPoint(x_car_pos, y_car_pos);
            }
            else{
                int x_car_pos = real_roadway_pos.x() - x_car_offset + cars_roadside_offset;
                return QPoint(x_car_pos, y_car_pos);
            }
        }
        else{
            int x_car_pos = mouse_event_mapped_to_scene.x();
            if(m_road_user_being_placed->get_horizontal_move_direction() == EHorizontalMoveDirection::right){
                int y_car_pos = real_roadway_pos.y() + roadway_height - car_height - cars_roadside_offset - y_car_offset;
                return QPoint(x_car_pos, y_car_pos);
            }
            else{
                int y_car_pos = real_roadway_pos.y() + cars_roadside_offset - y_car_offset;
                return QPoint(x_car_pos, y_car_pos);
            }
        }
    }
}

void CSimulationController::erase_selected_user(QMouseEvent *event)
{
    if(m_road_user_is_being_placed){
        m_road_user_is_being_placed = false;
        m_map_model->erase_road_user(m_road_user_being_placed);
        m_map_model->erase_item(m_validation_rect);
    }
    else{
        auto *item_at_mouse_pos = m_map_model->itemAt(this->m_map_view->mapToScene(event->pos()), this->m_map_view->transform());
        auto *road_user = dynamic_cast<CRoadUser*>(item_at_mouse_pos);

        if(road_user != nullptr){
            m_map_model->erase_road_user(road_user);
        }
    }
}

std::piecewise_linear_distribution<> CSimulationController::create_road_users_attribute_distribution(double min, double mean, double max)
{
    std::array<double, 3> x = {{min, mean, max}};
    std::array<double, 3> p = {{0, 1, 0}};

    return std::piecewise_linear_distribution<>(x.begin(), x.end(), p.begin());;
}

void CSimulationController::prepare_pedestrians_attributes_distributions()
{
    for(int i = 0; i < SRoadUsersBasicParameters::get_attributes_number(); i++){
        double min = m_simulation_configuration.m_pedestrians_min_basic_parameters.get_attribute_by_index(i);
        double mean = m_simulation_configuration.m_pedestrians_mean_basic_parameters.get_attribute_by_index(i);
        double max = m_simulation_configuration.m_pedestrians_max_basic_parameters.get_attribute_by_index(i);

        m_pedestrian_attributes_distributions.append(create_road_users_attribute_distribution(min, mean, max));
    }
}

void CSimulationController::prepare_cars_attributes_distributions()
{
    for(int i = 0; i < SRoadUsersBasicParameters::get_attributes_number(); i++){
        double min = m_simulation_configuration.m_cars_min_basic_parameters.get_attribute_by_index(i);
        double mean = m_simulation_configuration.m_cars_mean_basic_parameters.get_attribute_by_index(i);
        double max = m_simulation_configuration.m_cars_max_basic_parameters.get_attribute_by_index(i);

        m_cars_attributes_distributions.append(create_road_users_attribute_distribution(min, mean, max));
    }
}

SRoadUsersBasicParameters CSimulationController::prepare_road_users_parameters(QVector<std::piecewise_linear_distribution<>> &attributes_distributions)
{
    QVector<double> attributes_list;
    for(auto dist : attributes_distributions){
        attributes_list.append(dist(*m_generator));
    }

    return SRoadUsersBasicParameters(attributes_list);
}

void CSimulationController::prepare_validation_rect()
{
    m_validation_rect = new QGraphicsRectItem(0, 0, m_road_user_being_placed->boundingRect().width() + m_val_rect_size_offset,
                                              m_road_user_being_placed->boundingRect().height() + m_val_rect_size_offset);
    m_validation_rect->setBrush(Qt::red);
    m_validation_rect->setZValue(4);
    m_validation_rect->setOpacity(0.4);
    m_map_model->addItem(m_validation_rect);
}

EMapElementPositionValidity CSimulationController::get_current_user_position_validity(QMouseEvent *event)
{
    auto *dummy_road_user = new QGraphicsPixmapItem();
    dummy_road_user->setPixmap(m_road_user_being_placed->pixmap());
    dummy_road_user->setVisible(true);
    QPoint placement_pos = get_current_user_legal_position(event);

    if(placement_pos.x() == -1){
        return EMapElementPositionValidity::invalid;
    }

    dummy_road_user->setPos(placement_pos);
    if(m_road_user_being_placed->rotation() != 0){
        dummy_road_user->setTransformOriginPoint(dummy_road_user->boundingRect().center());
        dummy_road_user->setRotation(m_road_user_being_placed->rotation());
    }

    m_map_model->addItem(dummy_road_user);
    auto colliding_items = m_map_model->collidingItems(dummy_road_user);
    m_map_model->removeItem(dummy_road_user);
    delete dummy_road_user;

    bool at_least_one_proper_foundation = false;

    if(m_road_user_being_placed->get_road_user_type() == ERoadUsers::car){
        for(auto colliding_item : colliding_items){

            if(colliding_item == m_validation_rect){
                continue;
            }

            auto road_user = dynamic_cast<CRoadUser*>(colliding_item);
            if(road_user && road_user != m_road_user_being_placed){
                return EMapElementPositionValidity::invalid;
            }

            auto map_element = dynamic_cast<CStationaryMapElement*>(colliding_item);
            if(!map_element){
                continue;
            }

            EStationaryMapElementType map_element_type = map_element->get_map_element_type();

            if(map_element_type == EStationaryMapElementType::traffic_control_element){
                return EMapElementPositionValidity::invalid;
            }
            else if(map_element_type == EStationaryMapElementType::filler){
                continue;
            }

            CRoadElement *road_element = static_cast<CRoadElement*>(map_element);

            if(road_element->get_road_element_type() == ERoadElementType::pedestrian_crossing){
                if(road_element->get_movement_plane() == m_road_user_being_placed->get_current_movement_plane()){
                    return EMapElementPositionValidity::invalid;
                }
                else{
                    at_least_one_proper_foundation = true;
                    continue;
                }
            }

            if(road_element->get_permitted_road_users() == EPermittedRoadUsers::pedestrians){
                return EMapElementPositionValidity::invalid;
            }
            else{
                auto roadway_element = static_cast<CRoadwayElement*>(road_element);
                if(!roadway_element){
                    continue;
                }

                if(roadway_element->get_roadway_element_type() != ERoadwayElementType::roadway
                    || roadway_element->get_movement_plane() != m_road_user_being_placed->get_current_movement_plane()){
                    return EMapElementPositionValidity::invalid;
                }
                else{
                    at_least_one_proper_foundation = true;
                }
            }
        }
    }
    else{
        for(auto colliding_item : colliding_items){

            if(colliding_item == m_validation_rect){
                continue;
            }

            auto road_user = dynamic_cast<CRoadUser*>(colliding_item);
            if(road_user && road_user != m_road_user_being_placed){
                return EMapElementPositionValidity::invalid;
            }

            auto map_element = dynamic_cast<CStationaryMapElement*>(colliding_item);
            if(!map_element){
                continue;
            }

            EStationaryMapElementType map_element_type = map_element->get_map_element_type();

            if(map_element_type == EStationaryMapElementType::traffic_control_element){
                return EMapElementPositionValidity::invalid;
            }
            else if(map_element_type == EStationaryMapElementType::filler){
                continue;
            }

            CRoadElement *road_element = static_cast<CRoadElement*>(map_element);
            if(!road_element){
                continue;
            }

            if(road_element->get_road_element_type() != ERoadElementType::pavement){
                return EMapElementPositionValidity::invalid;
            }
            else{
                at_least_one_proper_foundation = true;
            }
        }
    }

    if(at_least_one_proper_foundation){
        return EMapElementPositionValidity::valid;
    }
    else{
        return EMapElementPositionValidity::invalid;
    }
}

void CSimulationController::update_validation_rect(QMouseEvent *event)
{
    auto pos_validity = get_current_user_position_validity(event);

    if(pos_validity == EMapElementPositionValidity::valid){
        m_validation_rect -> setBrush(Qt::green);
    }
    else{
        m_validation_rect -> setBrush(Qt::red);
    }
}

void CSimulationController::rotate_road_user_being_placed(QWheelEvent *event)
{
    int rotation_delta = event->angleDelta().y() / 90;
    qreal current_rotation = (int)m_road_user_being_placed->rotation() % 360;
    int new_rotation = qRound(current_rotation / 90) * 90 + rotation_delta * 90;
    int rotation_change = new_rotation - current_rotation; //either 90 or -90

    if(m_road_user_being_placed->get_current_movement_plane() == EMovementPlane::horizontal){
        m_road_user_being_placed->set_current_movement_plane(EMovementPlane::vertical);
        if(m_road_user_being_placed->get_horizontal_move_direction() == EHorizontalMoveDirection::right){
            if(rotation_change > 0){
                m_road_user_being_placed->set_vertical_move_direction(EVerticalMoveDirection::down);
            }
            else{
                m_road_user_being_placed->set_vertical_move_direction(EVerticalMoveDirection::up);
            }
        }
        else{
            if(rotation_change > 0){
                m_road_user_being_placed->set_vertical_move_direction(EVerticalMoveDirection::up);
            }
            else{
                m_road_user_being_placed->set_vertical_move_direction(EVerticalMoveDirection::down);
            }
        }
    }
    else{
        m_road_user_being_placed->set_current_movement_plane(EMovementPlane::horizontal);
        if(m_road_user_being_placed->get_vertical_move_direction() == EVerticalMoveDirection::up){
            if(rotation_change > 0){
                m_road_user_being_placed->set_horizontal_move_direction(EHorizontalMoveDirection::right);
            }
            else{
                m_road_user_being_placed->set_horizontal_move_direction(EHorizontalMoveDirection::left);
            }
        }
        else{
            if(rotation_change > 0){
                m_road_user_being_placed->set_horizontal_move_direction(EHorizontalMoveDirection::left);
            }
            else{
                m_road_user_being_placed->set_horizontal_move_direction(EHorizontalMoveDirection::right);
            }
        }
    }

    QPointF center = m_road_user_being_placed->boundingRect().center();
    m_road_user_being_placed->setTransformOriginPoint(center);
    m_road_user_being_placed->setRotation(new_rotation);

    m_validation_rect->setTransformOriginPoint(m_validation_rect->boundingRect().center());
    m_validation_rect->setRotation(new_rotation);
}

void CSimulationController::slot_process_simulation_step()
{

}

#ifndef CSIMULATIONCONTROLLER_H
#define CSIMULATIONCONTROLLER_H

#include <random>

#include "Logic/cmapcreationcontroller.h"
#include "cbasecontroller.h"
#include "MapElements/croaduser.h"
#include "MapElements/StationaryMapElements/TrafficControlElements/ctrafficlight.h"

struct SSimulationConfiguration{
    SRoadUsersBasicParameters m_cars_min_basic_parameters;
    SRoadUsersBasicParameters m_cars_mean_basic_parameters;
    SRoadUsersBasicParameters m_cars_max_basic_parameters;

    SRoadUsersBasicParameters m_pedestrians_min_basic_parameters;
    SRoadUsersBasicParameters m_pedestrians_mean_basic_parameters;
    SRoadUsersBasicParameters m_pedestrians_max_basic_parameters;

    STrafficLightsDuration m_traffic_lights_duration;

    bool m_place_road_users_automatically;
    int m_cars_to_place;
    int m_pedestrians_to_place;

    bool m_is_empty{true};

    SSimulationConfiguration() {};
    explicit SSimulationConfiguration(SRoadUsersBasicParameters cars_min_basic_parameters,
                                      SRoadUsersBasicParameters cars_mean_basic_parameters,
                                      SRoadUsersBasicParameters cars_max_basic_parameters,
                                      SRoadUsersBasicParameters pedestrians_min_basic_parameters,
                                      SRoadUsersBasicParameters pedestrians_mean_basic_parameters,
                                      SRoadUsersBasicParameters pedestrians_max_basic_parameters,
                                      STrafficLightsDuration traffic_lights_duration,
                                      bool place_road_users_automatically = false, int cars_to_place = 0, int pedestrians_to_place = 0){

        m_cars_min_basic_parameters = cars_min_basic_parameters;
        m_cars_mean_basic_parameters = cars_mean_basic_parameters;
        m_cars_max_basic_parameters = cars_max_basic_parameters;

        m_pedestrians_min_basic_parameters = pedestrians_min_basic_parameters;
        m_pedestrians_mean_basic_parameters = pedestrians_mean_basic_parameters;
        m_pedestrians_max_basic_parameters = pedestrians_max_basic_parameters;

        m_traffic_lights_duration = traffic_lights_duration;

        m_place_road_users_automatically = place_road_users_automatically;
        m_cars_to_place = cars_to_place;
        m_pedestrians_to_place = pedestrians_to_place;
        m_is_empty = false;
    }

    bool is_empty() {return m_is_empty;}
};

/**
 * @brief The CSimulationController class is a controller responsible for the traffic simulation process.
 *
 * The simulation is performed in discrete steps determined by a timer, the timeout of which is transmitted to the model
 * to update the state of the simulation.
 */

class CSimulationController : public CBaseController
{
    Q_OBJECT
public:
    CSimulationController (CApplicationController *application_controller, CEditableMap *map_model,
                          SSimulationConfiguration simulation_configuration);
    ~CSimulationController();

    void set_user_to_place_creation_func(CRoadUser *(*creation_func)(void));

    bool process_wheel_event(QWheelEvent *event);
    void process_mouse_move_event(QMouseEvent *event);
    void process_mouse_press_event(QMouseEvent *event);

    void start_simulation();
    void pause_simulation();
    void resume_simulation();
    void restart_simulation();

    bool simulation_is_ready() {return m_simulation_is_ready;}

    //TODO: recalculate everything with new config
    void set_simulation_configuration(SSimulationConfiguration simulation_configuration);
    void set_simulation_speed(uint simulation_speed);
    void configure_traffic_light(STrafficLightsDuration traffic_lights_duration);

private:
    SSimulationConfiguration m_simulation_configuration;
    QTimer m_simulation_timer;
    int m_simulation_step_interval{100};

    CTrafficLight *m_traffic_light_being_configured{nullptr};
    CRoadUser *m_road_user_being_configured{nullptr};
    CRoadUser *m_road_user_being_placed{nullptr};
    CRoadUser *(*m_current_creation_func)(void);
    QGraphicsRectItem *m_validation_rect{nullptr};
    bool m_road_user_is_being_placed{false};
    bool m_road_user_is_being_edited{false};

    void prepare_validation_rect();
    EMapElementPositionValidity get_current_user_position_validity(QMouseEvent *event);
    void update_validation_rect(QMouseEvent *event);
    int m_val_rect_size_offset{6};

    void rotate_road_user_being_placed(QWheelEvent *event);
    void place_user_and_prepare_next(QMouseEvent *event);
    QPoint get_current_user_legal_position(QMouseEvent *event);
    void erase_selected_user(QMouseEvent *event);
    int cars_roadside_offset{5};

    bool m_simulation_is_paused{true};
    bool m_simulation_is_ready{false};
    uint m_simulation_speed{1};
    std::mt19937 *m_generator;
    QVector<std::piecewise_linear_distribution<>> m_pedestrian_attributes_distributions;
    QVector<std::piecewise_linear_distribution<>> m_cars_attributes_distributions;

    std::piecewise_linear_distribution<> create_road_users_attribute_distribution(double min, double mean, double max);

    void prepare_pedestrians_attributes_distributions();
    void prepare_cars_attributes_distributions();
    SRoadUsersBasicParameters prepare_road_users_parameters(QVector<std::piecewise_linear_distribution<>> &attributes_distributions);

private slots:
    void slot_process_simulation_step();

signals:
    void signal_road_user_configuration_requested(SRoadUsersBasicParameters parameters);
    void signal_traffic_light_configuration_requested(STrafficLightsDuration traffic_lights_duration);

};

#endif // CSIMULATIONCONTROLLER_H

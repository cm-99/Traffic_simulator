#ifndef CCAR_H
#define CCAR_H

#include "MapElements/croaduser.h"

/**
 * @brief The CCar class is a graphical and behavioral representation of a car.
 */
class CCar : public CRoadUser
{
public:
    static CRoadUser *create_car();

    virtual void move() override;

private:
    CCar(QPixmap car_pixmap, QString description, EMovementPlane movement_plane,
         EHorizontalMoveDirection horizontal_move_direction = EHorizontalMoveDirection::left,
         EVerticalMoveDirection vertical_move_direction = EVerticalMoveDirection::up);
};

#endif // CCAR_H

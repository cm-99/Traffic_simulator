#include "cpedestrian.h"

CPedestrian::CPedestrian(QVector<QPixmap> pedestrian_states_pixmaps, QString description, EMovementPlane movement_plane,
                         EHorizontalMoveDirection horizontal_move_direction, EVerticalMoveDirection vertical_move_direction) :
    CRoadUser(ERoadUsers::pedestrian, description, movement_plane, horizontal_move_direction, vertical_move_direction)
{
    setPixmap(pedestrian_states_pixmaps[0]);
}

CRoadUser *CPedestrian::create_pedestrian()
{
    return new CPedestrian(QVector<QPixmap>{QPixmap(":/graphics/map_elements_graphics/road_users/pedestrians/pedestrian_right_still.png"),
                                            QPixmap(":/graphics/map_elements_graphics/road_users/pedestrians/pedestrian_right.png"),
                                            QPixmap(":/graphics/map_elements_graphics/road_users/pedestrians/pedestrian_right_2.png")},
                           "Pedestrian", EMovementPlane::horizontal, EHorizontalMoveDirection::right);
}

void CPedestrian::move()
{

}

